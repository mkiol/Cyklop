/**
 * Cyklop global file
 */

.pragma library

var pageStack = null;
var stationsPage = null;
